Page Atelier 集客開始セット / 2026-10-08
最新の集客方針はall-industries-plan.md。旧資料の施工会社集中案は廃止。
最新の状態はconnection-guide.md、毎日運用はdaily-publishing-plan.mdを参照。
記事・画像・投稿文は14日分を準備済み。GitHub接続とGA4アクセス受信は確認済み。Instagramの公式API接続・実投稿は未完了。
05-launch-executionは初回公開時点の実行記録です。
相談管理表は非公開コピーで使い、記入後のファイルはGitHubへ戻さないでください。
トークン・APIキー・顧客の秘密情報をチャットや公開リポジトリへ送らないでください。
